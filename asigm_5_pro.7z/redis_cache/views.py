# from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework.response import Response
from django.core.cache import cache
from django.conf import settings
from django.core.cache.backends.base import DEFAULT_TIMEOUT

CACHE_TTL = getattr(settings, 'CACHE_TTL', DEFAULT_TIMEOUT)
from .models import Product

# Create your views here.
@api_view(['GET'])
def get_products(request):
    # if 'products' in cache:
    #     products = cache.get('products')
    #     return Response(products, status=status.HTTP_201_CERATED)

    # else:
        products = Product.objects.all()
        results = [product.to_json() for product in products]
        # cache.set('product', results, timeout=CACHE_TTL)
        return Response(results, status=status.HTTP_201_CREATED)
